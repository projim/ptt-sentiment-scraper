## Reproduction of "format" problem

When I import the format function from date-fns package, the imported function triggers a Typescript warning, 
saying 'format' cannot be used as a value because it was exported using 'export type'.