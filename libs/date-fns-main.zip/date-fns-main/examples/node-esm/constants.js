import { maxTime } from "date-fns/constants";

console.log(maxTime === 8640000000000000);
