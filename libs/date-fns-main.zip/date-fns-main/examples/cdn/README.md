# Usage With CDN

See [basic.js](./basic.js), [fp.js](./fp.js), [locale.js](./locale.js) and [locales.js](./locales.js) for source code examples.

See [package.json scripts](./package.json) for CLI usage
