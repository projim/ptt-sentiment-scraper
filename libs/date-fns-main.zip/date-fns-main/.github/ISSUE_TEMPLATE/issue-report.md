## The problem

### 💻 Code demonstrating the problem

<!-- Demonstrate the problem -->

```
js
import { fn } from 'date-fns'

fn()
//=> Problematic output
```

### 🙁 Actual behavior

<!-- Describe what you are getting -->

### 🙂 Expected behavior

<!-- Describe what you are expecting to get -->

## Debug information

- date-fns version: <!-- Fill in the date-fns version you use -->
- Browser/Node.js version: <!-- Fill in the envrionment version (i.e. Chrome 94.0.4606.61) -->
- Your timezone: <!-- Fill in your timezone name (i.e. Asia/Singapore) -->
- Your current time: <!-- Fill in the time when did you tested the problem (i.e. 16:20) -->
