// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isWednesday as fn } from "../../isWednesday/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isWednesdayWithOptions = convertToFP(fn, 2);
