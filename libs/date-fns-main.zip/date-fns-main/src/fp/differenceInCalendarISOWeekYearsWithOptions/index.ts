// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInCalendarISOWeekYears as fn } from "../../differenceInCalendarISOWeekYears/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInCalendarISOWeekYearsWithOptions = convertToFP(fn, 3);
