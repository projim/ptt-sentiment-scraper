// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatDistanceStrict as fn } from "../../formatDistanceStrict/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatDistanceStrict = convertToFP(fn, 2);
