// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { endOfMonth as fn } from "../../endOfMonth/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const endOfMonthWithOptions = convertToFP(fn, 2);
