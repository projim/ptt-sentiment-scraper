// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isExists as fn } from "../../isExists/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isExists = convertToFP(fn, 3);
