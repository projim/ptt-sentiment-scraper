// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isWeekend as fn } from "../../isWeekend/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isWeekendWithOptions = convertToFP(fn, 2);
