// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { endOfDay as fn } from "../../endOfDay/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const endOfDay = convertToFP(fn, 1);
