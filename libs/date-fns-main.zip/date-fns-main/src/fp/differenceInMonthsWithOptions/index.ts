// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInMonths as fn } from "../../differenceInMonths/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInMonthsWithOptions = convertToFP(fn, 3);
