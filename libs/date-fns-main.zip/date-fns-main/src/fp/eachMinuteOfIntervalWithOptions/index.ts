// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { eachMinuteOfInterval as fn } from "../../eachMinuteOfInterval/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const eachMinuteOfIntervalWithOptions = convertToFP(fn, 2);
