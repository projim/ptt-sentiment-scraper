// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { clamp as fn } from "../../clamp/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const clamp = convertToFP(fn, 2);
