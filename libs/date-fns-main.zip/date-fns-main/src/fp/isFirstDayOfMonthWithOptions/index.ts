// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isFirstDayOfMonth as fn } from "../../isFirstDayOfMonth/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isFirstDayOfMonthWithOptions = convertToFP(fn, 2);
