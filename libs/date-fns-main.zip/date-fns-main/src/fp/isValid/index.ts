// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isValid as fn } from "../../isValid/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isValid = convertToFP(fn, 1);
