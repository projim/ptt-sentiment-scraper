// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { eachWeekendOfYear as fn } from "../../eachWeekendOfYear/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const eachWeekendOfYearWithOptions = convertToFP(fn, 2);
