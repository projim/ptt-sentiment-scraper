// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { compareDesc as fn } from "../../compareDesc/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const compareDesc = convertToFP(fn, 2);
