// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isSameMonth as fn } from "../../isSameMonth/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isSameMonth = convertToFP(fn, 2);
