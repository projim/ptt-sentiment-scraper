// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInCalendarMonths as fn } from "../../differenceInCalendarMonths/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInCalendarMonths = convertToFP(fn, 2);
