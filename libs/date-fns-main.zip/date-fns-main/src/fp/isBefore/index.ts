// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isBefore as fn } from "../../isBefore/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isBefore = convertToFP(fn, 2);
