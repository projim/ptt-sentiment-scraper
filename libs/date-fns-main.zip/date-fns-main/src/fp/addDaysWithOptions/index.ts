// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { addDays as fn } from "../../addDays/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const addDaysWithOptions = convertToFP(fn, 3);
