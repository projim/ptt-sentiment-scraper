// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { hoursToMinutes as fn } from "../../hoursToMinutes/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const hoursToMinutes = convertToFP(fn, 1);
