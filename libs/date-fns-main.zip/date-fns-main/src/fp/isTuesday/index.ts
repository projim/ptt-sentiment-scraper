// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isTuesday as fn } from "../../isTuesday/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isTuesday = convertToFP(fn, 1);
