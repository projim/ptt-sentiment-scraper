// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getISOWeekYear as fn } from "../../getISOWeekYear/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getISOWeekYearWithOptions = convertToFP(fn, 2);
