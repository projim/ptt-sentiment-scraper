// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { addHours as fn } from "../../addHours/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const addHours = convertToFP(fn, 2);
