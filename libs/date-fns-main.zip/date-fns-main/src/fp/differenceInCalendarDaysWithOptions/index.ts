// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInCalendarDays as fn } from "../../differenceInCalendarDays/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInCalendarDaysWithOptions = convertToFP(fn, 3);
