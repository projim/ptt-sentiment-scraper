// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getQuarter as fn } from "../../getQuarter/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getQuarterWithOptions = convertToFP(fn, 2);
