// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatRFC7231 as fn } from "../../formatRFC7231/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatRFC7231 = convertToFP(fn, 1);
