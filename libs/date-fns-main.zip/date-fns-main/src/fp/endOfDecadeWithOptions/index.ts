// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { endOfDecade as fn } from "../../endOfDecade/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const endOfDecadeWithOptions = convertToFP(fn, 2);
