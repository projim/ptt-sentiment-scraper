// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatISO as fn } from "../../formatISO/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatISO = convertToFP(fn, 1);
