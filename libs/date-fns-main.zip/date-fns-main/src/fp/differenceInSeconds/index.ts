// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInSeconds as fn } from "../../differenceInSeconds/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInSeconds = convertToFP(fn, 2);
