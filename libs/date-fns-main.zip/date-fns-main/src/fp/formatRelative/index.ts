// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatRelative as fn } from "../../formatRelative/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatRelative = convertToFP(fn, 2);
