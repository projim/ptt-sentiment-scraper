// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { addWeeks as fn } from "../../addWeeks/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const addWeeksWithOptions = convertToFP(fn, 3);
