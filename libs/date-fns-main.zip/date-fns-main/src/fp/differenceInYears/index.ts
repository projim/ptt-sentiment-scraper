// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInYears as fn } from "../../differenceInYears/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInYears = convertToFP(fn, 2);
