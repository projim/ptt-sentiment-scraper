// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getISOWeeksInYear as fn } from "../../getISOWeeksInYear/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getISOWeeksInYear = convertToFP(fn, 1);
