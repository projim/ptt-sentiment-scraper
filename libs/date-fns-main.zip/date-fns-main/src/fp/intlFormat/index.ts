// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { intlFormat as fn } from "../../intlFormat/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const intlFormat = convertToFP(fn, 3);
