// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isSameDay as fn } from "../../isSameDay/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isSameDay = convertToFP(fn, 2);
