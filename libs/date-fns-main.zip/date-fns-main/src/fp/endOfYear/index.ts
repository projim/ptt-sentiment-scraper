// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { endOfYear as fn } from "../../endOfYear/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const endOfYear = convertToFP(fn, 1);
