// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isWithinInterval as fn } from "../../isWithinInterval/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isWithinIntervalWithOptions = convertToFP(fn, 3);
