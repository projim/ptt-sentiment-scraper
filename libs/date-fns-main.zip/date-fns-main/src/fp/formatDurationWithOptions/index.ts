// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatDuration as fn } from "../../formatDuration/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatDurationWithOptions = convertToFP(fn, 2);
