// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { eachYearOfInterval as fn } from "../../eachYearOfInterval/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const eachYearOfInterval = convertToFP(fn, 1);
