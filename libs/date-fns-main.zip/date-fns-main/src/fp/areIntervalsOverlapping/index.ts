// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { areIntervalsOverlapping as fn } from "../../areIntervalsOverlapping/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const areIntervalsOverlapping = convertToFP(fn, 2);
