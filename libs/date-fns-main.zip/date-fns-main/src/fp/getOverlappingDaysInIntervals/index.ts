// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getOverlappingDaysInIntervals as fn } from "../../getOverlappingDaysInIntervals/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getOverlappingDaysInIntervals = convertToFP(fn, 2);
