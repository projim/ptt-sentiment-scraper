// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { constructFrom as fn } from "../../constructFrom/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const constructFrom = convertToFP(fn, 2);
