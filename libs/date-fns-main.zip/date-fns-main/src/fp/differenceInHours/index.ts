// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInHours as fn } from "../../differenceInHours/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInHours = convertToFP(fn, 2);
