// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { endOfSecond as fn } from "../../endOfSecond/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const endOfSecond = convertToFP(fn, 1);
