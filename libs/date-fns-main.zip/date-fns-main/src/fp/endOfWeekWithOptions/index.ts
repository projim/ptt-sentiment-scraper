// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { endOfWeek as fn } from "../../endOfWeek/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const endOfWeekWithOptions = convertToFP(fn, 2);
