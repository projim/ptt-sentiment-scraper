// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isAfter as fn } from "../../isAfter/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isAfter = convertToFP(fn, 2);
