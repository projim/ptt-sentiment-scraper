// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatISO9075 as fn } from "../../formatISO9075/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatISO9075WithOptions = convertToFP(fn, 2);
