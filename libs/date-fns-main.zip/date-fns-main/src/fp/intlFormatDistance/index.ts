// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { intlFormatDistance as fn } from "../../intlFormatDistance/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const intlFormatDistance = convertToFP(fn, 2);
