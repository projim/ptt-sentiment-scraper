// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { eachQuarterOfInterval as fn } from "../../eachQuarterOfInterval/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const eachQuarterOfIntervalWithOptions = convertToFP(fn, 2);
