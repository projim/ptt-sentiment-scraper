// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isMonday as fn } from "../../isMonday/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isMonday = convertToFP(fn, 1);
