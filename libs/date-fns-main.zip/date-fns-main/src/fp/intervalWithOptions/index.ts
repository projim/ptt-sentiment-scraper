// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { interval as fn } from "../../interval/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const intervalWithOptions = convertToFP(fn, 3);
