// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isSameSecond as fn } from "../../isSameSecond/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isSameSecond = convertToFP(fn, 2);
