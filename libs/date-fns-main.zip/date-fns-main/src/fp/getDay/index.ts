// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getDay as fn } from "../../getDay/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getDay = convertToFP(fn, 1);
