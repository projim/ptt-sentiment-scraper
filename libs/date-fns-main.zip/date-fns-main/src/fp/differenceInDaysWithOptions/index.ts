// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { differenceInDays as fn } from "../../differenceInDays/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const differenceInDaysWithOptions = convertToFP(fn, 3);
