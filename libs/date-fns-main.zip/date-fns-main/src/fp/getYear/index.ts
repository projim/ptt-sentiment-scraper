// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getYear as fn } from "../../getYear/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getYear = convertToFP(fn, 1);
