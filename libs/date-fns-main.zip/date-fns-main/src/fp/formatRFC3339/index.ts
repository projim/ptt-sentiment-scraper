// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatRFC3339 as fn } from "../../formatRFC3339/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatRFC3339 = convertToFP(fn, 1);
