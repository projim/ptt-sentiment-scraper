// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { formatISODuration as fn } from "../../formatISODuration/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const formatISODuration = convertToFP(fn, 1);
