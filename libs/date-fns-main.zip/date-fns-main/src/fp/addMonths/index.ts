// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { addMonths as fn } from "../../addMonths/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const addMonths = convertToFP(fn, 2);
