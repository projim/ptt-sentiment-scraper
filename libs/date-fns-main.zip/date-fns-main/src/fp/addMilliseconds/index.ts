// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { addMilliseconds as fn } from "../../addMilliseconds/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const addMilliseconds = convertToFP(fn, 2);
