// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getDayOfYear as fn } from "../../getDayOfYear/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getDayOfYearWithOptions = convertToFP(fn, 2);
