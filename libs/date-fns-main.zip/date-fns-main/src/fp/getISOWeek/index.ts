// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { getISOWeek as fn } from "../../getISOWeek/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const getISOWeek = convertToFP(fn, 1);
