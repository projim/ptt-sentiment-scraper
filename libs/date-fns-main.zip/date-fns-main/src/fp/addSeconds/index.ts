// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { addSeconds as fn } from "../../addSeconds/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const addSeconds = convertToFP(fn, 2);
