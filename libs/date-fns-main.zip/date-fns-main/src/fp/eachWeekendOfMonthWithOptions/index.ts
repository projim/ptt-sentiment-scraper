// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { eachWeekendOfMonth as fn } from "../../eachWeekendOfMonth/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const eachWeekendOfMonthWithOptions = convertToFP(fn, 2);
