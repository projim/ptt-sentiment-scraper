// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { isSunday as fn } from "../../isSunday/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const isSundayWithOptions = convertToFP(fn, 2);
