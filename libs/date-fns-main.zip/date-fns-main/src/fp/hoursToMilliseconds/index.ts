// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

import { hoursToMilliseconds as fn } from "../../hoursToMilliseconds/index.js";
import { convertToFP } from "../_lib/convertToFP/index.js";

export const hoursToMilliseconds = convertToFP(fn, 1);
